package status

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"os"
	"time"
)

/**
 * 状态结构体
 */
type Status struct {
	UpperLatitude         float64 `json:"upperLatitude"`         //上纬度
	LowerLatitude         float64 `json:"lowerLatitude"`         //下纬度
	LeftLongitude         float64 `json:"leftLongitude"`         //左经度
	RightLongitude        float64 `json:"rightLongitude"`        //右经度
	ApiAvailableTimes     int     `json:"apiAvailableTimes"`     //API可用次数
	LastUseDate           string  `json:"lastUseDate"`           //上次使用日期
	ApiKey                string  `json:"apiKey"`                //API Key
	LastLongitudePosition float64 `json:"lastLongitudePosition"` //上次抓取经度位置
	LastLatitudePosition  float64 `json:"lastLatitudePosition"`  //上次抓取纬度位置
	LastCategoryIndex     int     `json:"lastCategoryIndex"`     //上次抓取类别索引
	LastLongitudeLength   float64 `json:"lastLongitudeLength"`   //上次抓取矩形区域横向宽度（经度位移）
	LastLatitudeLength    float64 `json:"lastLatitudeLength"`    //上次抓取矩形区域纵向高度（纬度位移）
	LastPageIndex         int     `json:"lastPageIndex"`         //上次抓取页索引
}

/*
 * 保存状态
 */
func (s *Status) Save(path string) error {

	data, err := json.MarshalIndent(s, "", "	")
	if nil != err {
		log.Println("状态数据保存失败！")
		return err
	}
	ioutil.WriteFile(path, data, os.ModeDir)
	return nil
}

/**
 * 加载状态
 */
func (s *Status) Load(path string) error {
	data, err := ioutil.ReadFile(path)
	if nil != err {
		log.Println("无状态数据" + path)
		return err
	}
	json.Unmarshal(data, s)
	return nil
}

var category = []string{
	"酒店", "生活服务", "房地产", "汽车服务",
	"教育培训", "丽人", "运动健身", "美食",
	"政府机构", "自然地物", "公司企业", "交通设施",
	"旅游景点", "医疗", "文化传媒", "出入口", "购物",
	"休闲娱乐", "金融"}

/**
 * 获取类别
 */
func (s Status) GetCategory() string {
	return category[s.LastCategoryIndex]
}

/**
 * 类别数量
 */
func (s Status) CategorySize() int {
	return len(category)
}

/**
 * 重置API
 */
func (s *Status) Reset() {
	s.UpperLatitude = 0
	s.LowerLatitude = 0
	s.LeftLongitude = 0
	s.RightLongitude = 0
	s.ApiAvailableTimes = 2000
	s.LastUseDate = today()
	s.ApiKey = "api key"
	s.LastLongitudePosition = 0
	s.LastLatitudePosition = 0
	s.LastCategoryIndex = 0
	s.LastLongitudeLength = 0.0005
	s.LastLatitudeLength = 0.002
	s.LastPageIndex = -1
}

/**
 * 更新API的使用次数
 */
func (s *Status) RefreshApiAvairableTimes() {
	today := today()
	if s.LastUseDate != today {
		s.LastUseDate = today
		s.ApiAvailableTimes = 2000
	}
}

func today() string {
	now := time.Now()
	return fmt.Sprintf("%4d%2d%2d", now.Year(), now.Month(), now.Day())
}
