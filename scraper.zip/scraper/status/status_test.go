package status

import (
	"testing"
)

func TestSave(t *testing.T) {

	s := &Status{
		UpperLatitude:         39.54321,
		LowerLatitude:         38.76623,
		LeftLongitude:         116.43213,
		RightLongitude:        116.46733,
		ApiAvailableTimes:     2000,
		LastUseDate:           "20181217",
		ApiKey:                "x8iQkSGXj4AgoU47gRmCr3SBPdKMt5vZ",
		LastLongitudePosition: 0,
		LastLatitudePosition:  0,
		LastCategoryIndex:     0,
		LastLongitudeLength:   0.001,
		LastLatitudeLength:    0.001,
		LastPageIndex:         0}

	s.Save("F:/projects/BaiduMapScraper/bin/test_status.json")
}

func TestLoad(t *testing.T) {
	s := Status{}
	s.Load("F:/projects/BaiduMapScraper/bin/test_status.json")
}
