package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"math"
	"net/http"
	"os"
	"regexp"
	"scraper/poi"
	"scraper/status"
	"strconv"
	"time"
)

var statusFileName = "./status.json"

func main() {

	s := &status.Status{}

	scanner := bufio.NewScanner(os.Stdin)

	// 表示表示没有未抓取完整的任务
	if s.Load(statusFileName) != nil ||
		(s.LastLongitudePosition >= s.RightLongitude && s.LastLatitudePosition <= s.LowerLatitude) {
		NewScrape(s, scanner)
	} else {
		GoOnScrape(s, scanner)
	}
}

/**
 * 继续抓取
 */
func GoOnScrape(s *status.Status, scanner *bufio.Scanner) {
	s.RefreshApiAvairableTimes()
SELECT_MODE:
	fmt.Printf("检测到上次%s没有抓取完整，是否继续抓取？ 是(Y) 否(N)", s.LastUseDate)
	scanner.Scan()
	input := scanner.Text()
	if "Y" != input && "N" != input {
		fmt.Println("请输入 Y 或者 N")
		goto SELECT_MODE
	}

	if "Y" == input {
		Scrape(s)
	} else {
		NewScrape(s, scanner)
	}
}

/**
 * 重新抓取
 */
func NewScrape(s *status.Status, scanner *bufio.Scanner) {

	s.Reset()
	regex := regexp.MustCompile("[0-9]{1,3}\\.[0-9]{5}")
	s.LeftLongitude = scanFloat(scanner, regex, "左经度")
	s.RightLongitude = scanFloat(scanner, regex, "右经度")
	s.UpperLatitude = scanFloat(scanner, regex, "上纬度")
	s.LowerLatitude = scanFloat(scanner, regex, "下纬度")

	s.LastLongitudePosition = s.LeftLongitude
	s.LastLatitudePosition = s.UpperLatitude
	s.Save(statusFileName)
	Scrape(s)
}

func scanFloat(scanner *bufio.Scanner, regex *regexp.Regexp, name string) float64 {
BEGIN_SCAN:
	fmt.Printf("请输入要抓取矩形区域的%s（保留5位小数）：", name)
	scanner.Scan()
	input := scanner.Text()
	if !regex.MatchString(input) {
		fmt.Printf("输入的%s不合法，请重新输入\n", name)
		goto BEGIN_SCAN
	}
	result, _ := strconv.ParseFloat(input, 5)
	return result
}

func Scrape(s *status.Status) {
	log.Println("开始抓取 ...")
	log.Printf("左经度：%f\n", s.LeftLongitude)
	log.Printf("右经度：%f\n", s.RightLongitude)
	log.Printf("上纬度：%f\n", s.UpperLatitude)
	log.Printf("下纬度：%f\n\n", s.LowerLatitude)

	for ; s.LastCategoryIndex < s.CategorySize(); s.LastCategoryIndex++ {
		f, err := os.OpenFile(fmt.Sprintf("%f_%f_%f_%f_%s.txt", s.LowerLatitude, s.LeftLongitude, s.UpperLatitude, s.RightLongitude, s.GetCategory()), os.O_APPEND|os.O_WRONLY|os.O_CREATE, 0600)
		if err != nil {
			log.Panic("打开文件出错。", err)
		}
		defer f.Close()

		for ; s.LastLatitudePosition > s.LowerLatitude; s.LastLatitudePosition -= s.LastLatitudeLength {
			s.LastLatitudePosition = math.Round(s.LastLatitudePosition*100000) / 100000
			for s.LastLongitudePosition < s.RightLongitude {
				upper := s.LastLatitudePosition
				lower := upper - s.LastLatitudeLength
				left := s.LastLongitudePosition
				right := left + s.LastLongitudeLength

			NEXT_PAGE:
				if s.ApiAvailableTimes < 1 {
					log.Println("今日API次数用完了")
					os.Exit(0)
				}
				log.Printf("开始抓取[%.5f,%.5f,%.5f,%.5f], %s, 页号：%d", lower, left, upper, right, s.GetCategory(), s.LastPageIndex+1)
				time.Sleep(500000000) //避免超出频率限制
				s.ApiAvailableTimes--
				url := fmt.Sprintf("http://api.map.baidu.com/place/v2/search?output=json&page_size=20&scope=1&coord_type=1&query=%s&bounds=%.5f,%.5f,%.5f,%.5f&ak=%s&page_num=%d",
					s.GetCategory(), lower, left, upper, right, s.ApiKey, s.LastPageIndex+1)

				resp, err := http.Get(url)
				if nil != err {
					log.Panic("网络出现错误", err)
				} else {
					defer resp.Body.Close()
					body, err := ioutil.ReadAll(resp.Body)
					if err != nil {
						log.Panic("读取HTTP Body数据时出错", err)
					}
					poiResponse := &poi.PoiResponse{}
					err = json.Unmarshal(body, poiResponse)
					if nil != err {
						log.Println("解析服务器返回的数据出错，5秒后重新获取", err)
						time.Sleep(5000000000)
					} else if poiResponse.Status != 0 {
						log.Printf("未能成功获取POI数据，服务器返回：%s\n", poiResponse.Message)
						time.Sleep(5000000000)
					} else {
						if poiResponse.Total == 0 { //没有获取到数据
							//扩大矩形面积
							log.Printf("未能获取到数据，区域宽度（经度）由%f调整为%f\n", s.LastLongitudeLength, s.LastLongitudeLength*2)
							s.LastLongitudePosition += s.LastLongitudeLength
							//加个判断，不能让它无限膨胀
							if s.LastLongitudeLength*2 < s.RightLongitude-s.LeftLongitude {
								s.LastLongitudeLength *= 2
							}
							s.Save(statusFileName)
						} else if poiResponse.Total == 400 { //获取的数据达到400上限，可能不完整
							log.Printf("获取的数据总数达到400条，可能不完整，区域宽度（经度）由%f调整为%f\n", s.LastLongitudeLength, s.LastLongitudeLength/2)
							//缩小矩形面积
							s.LastLongitudeLength /= 2
						} else { // 获取的数据在 0 到 400之间，有效
							log.Printf("获取的数据总条数为%d,有效！\n", poiResponse.Total)

							for _, p := range poiResponse.Results {
								record := fmt.Sprintf("%s,%f,%f,%s,%s,%s,%s,%s\n", p.Name, p.Location.Lgt, p.Location.Lat, p.Telephone, p.Province, p.City, p.Area, p.Address)
								log.Print(record)
								if _, err = f.WriteString(record); err != nil {
									panic(err)
								}
							}

							size := len(poiResponse.Results)
							if size == 20 { //表示还有下一页
								log.Printf("当前页数据条数为20条，表示不是末尾页，页号+1")
								s.LastPageIndex++
								s.Save(statusFileName)
								goto NEXT_PAGE
							} else {
								log.Printf("当前页数据为%d条，是末尾页，页号重置", size)
								s.LastPageIndex = -1
								s.LastLongitudePosition += s.LastLongitudeLength
								s.Save(statusFileName)
							}
						}
					}
				}
			}
			log.Printf("抓取完一行，纬度由%f调整为%f", s.LastLatitudePosition, s.LastLatitudePosition+s.LastLatitudeLength)
			//抓完一行了，经度回到原点
			s.LastLongitudePosition = s.LeftLongitude
			s.Save(statusFileName)
		}
		f.Close()
		//抓完一个类别了，回到原点
		s.LastLatitudeLength = s.UpperLatitude
		s.LastCategoryIndex++
		s.Save(statusFileName)
	}
}
